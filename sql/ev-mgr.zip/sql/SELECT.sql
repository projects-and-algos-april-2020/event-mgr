USE event_manager;
-- 2020-04-22 03:15:56

SELECT * FROM events
-- SELECT * FROM student_acct_events